import netCDF4 as nc
import os
if __name__ == '__main__':
    nc_path = 'TrueNc/2020_07_11_22_00.nc'

    print(os.path.exists(nc_path))

    nc_file = nc.Dataset(nc_path)

    print(nc_file.variables['Flash_pre'][:,:])

    print('ok')
